/*Tables with Attributes and relationships creation*/
create table parent(
parent_phone varchar(30) PRIMARY key,
parent_fname varchar(30) not null,
parent_lname varchar(30) not null,
relationship varchar(30) not null,
occupation varchar(30) not null,
parent_address varchar(30) not null
);

create table student(
student_id int not null PRIMARY key,
first_name varchar(30) not null,
last_name varchar(30) not null,
dob date,
email varchar(30) not null,
course varchar(30) not null,
parent_phone varchar(30),
foreign key(parent_phone) references parent(parent_phone)
);


create table lecturer(
lecturer_id varchar(30) PRIMARY key,
lecturer_fname varchar(30) not null,
lecturer_lname varchar(30) not null,
email varchar(30) not null,
salary int not null,
lecturer_address varchar(30) not null
);



create table module(
module_id varchar(6) not null PRIMARY key,
module_name varchar(30) not null,
semester varchar(15) not null,
department varchar(30) not null,
credit_hours int not null,
lecturer_id varchar(30),
foreign key(lecturer_id) references lecturer(lecturer_id),
student_id int,
foreign key(student_id) references student(student_id)
);

create table staff(
staff_no varchar(5) not null PRIMARY key,
position varchar(30) not null,
email varchar(30) not null,
dob date not null,
phone varchar(30),
lecturer_id varchar(30),
foreign key(lecturer_id) references lecturer(lecturer_id)
)


/*Data Insertion*/
insert into parent(parent_phone, parent_fname, parent_lname, relationship, occupation, parent_address)
VALUES('079111111', 'Jeneba', 'Kargbo', 'mother', 'trader', '12 Kissy Rd, Freetown');

insert into parent(parent_phone, parent_fname, parent_lname, relationship, occupation, parent_address)
VALUES('079111222', 'Hassan', 'Turay', 'Father', 'Lawyer', '66 Bai Bureh Rd, Freetown');

insert into parent(parent_phone, parent_fname, parent_lname, relationship, occupation, parent_address)
VALUES('079111333', 'Osman', 'Sesay', 'Father', 'Teacher', '55 Wilkinson Rd, Freetown');

insert into parent(parent_phone, parent_fname, parent_lname, relationship, occupation, parent_address)
VALUES('079111444', 'Agness', 'Bona', 'Mother', 'Accountant', '89 Kissy Rd, Freetown');

insert into parent(parent_phone, parent_fname, parent_lname, relationship, occupation, parent_address)
VALUES('079111555', 'James', 'Tucker', 'Father', 'Trader', '106 Congo Cross Rd');




insert into student(student_id, first_name, last_name, dob, email, course, parent_phone)
VALUES(0001, 'Francis Agibu', 'Kargbo', '11/05/2000', 'agibu@gmail.com', 'Fullstack', '079111111');

insert into student(student_id, first_name, last_name, dob, email, course, parent_phone)
VALUES(0002, 'James ', 'Turay', '11/05/2001', 'turay@gmail.com', 'Frontend', '079111222');

insert into student(student_id, first_name, last_name, dob, email, course, parent_phone)
VALUES(0003, 'Abass', 'Kanu', '01/08/1989', 'kanu@gmail.com', 'Backend', '079111333');

insert into student(student_id, first_name, last_name, dob, email, course, parent_phone)
VALUES(0004, 'Ramadan', 'Barrie', '08/11/1998', 'barrie@gmail.com', 'Frontend', '079111444');

insert into student(student_id, first_name, last_name, dob, email, course, parent_phone)
VALUES(0005, 'Mohamed C.F', 'Woobay', '01/02/2000', 'woobay@gmail.com', 'Fullstack', '079111555');




insert into lecturer(lecturer_id, lecturer_fname, lecturer_lname, email, salary, lecturer_address)
VALUES('LI001', 'Bayoh', 'Turay', 'bayoh@gmail.com', '10000', '13 Bai Bureh Rd');

insert into lecturer(lecturer_id, lecturer_fname, lecturer_lname, email, salary, lecturer_address)
VALUES('LI002', 'Titus', 'Nabie', 'nabie@gmail.com', '19000', '176 Congo Cross');

insert into lecturer(lecturer_id, lecturer_fname, lecturer_lname, email, salary, lecturer_address)
VALUES('LI003', 'Joshua', 'Charley', 'charley@gmail.com', '10000', '88 PWD Byepass');

insert into lecturer(lecturer_id, lecturer_fname, lecturer_lname, email, salary, lecturer_address)
VALUES('LI004', 'Francis Agibu', 'Kargbo', 'kargbo@gmail.com', '20000', '176 Bus Hult');

insert into lecturer(lecturer_id, lecturer_fname, lecturer_lname, email, salary, lecturer_address)
VALUES('LI005', 'Agibu', 'Kargbo', 'agibu@gmail.com', '25000', '128 Fisher Lane');




insert into module(module_id, module_name, semester, department, credit_hours, lecturer_id, student_id)
VALUES('CUM100', 'HTML & CSS', '1', 'Web Frontend', '4', 'LI001', 0001);

insert into module(module_id, module_name, semester, department, credit_hours, lecturer_id, student_id)
VALUES('CUM101', 'JavaScripts', '2', 'Web Frontend', '4', 'LI002', 0002);

insert into module(module_id, module_name, semester, department, credit_hours, lecturer_id, student_id)
VALUES('CUM102', 'PHP', '1', 'Web Backend', '5', 'LI003', 0003);

insert into module(module_id, module_name, semester, department, credit_hours, lecturer_id, student_id)
VALUES('CUM103', 'MongoDB', '2', 'Web Backend', '4', 'LI004', 0002);

insert into module(module_id, module_name, semester, department, credit_hours, lecturer_id, student_id)
VALUES('CUM104', 'Python', '2', 'Web Front & Backend', '4', 'LI005', 0001);




insert into staff(staff_no, position, email, dob, phone, lecturer_id)
VALUES('SN001', 'Lecturer', 'bayoh@gmail.com', '03/10/1998', '076123111', 'LI001');

insert into staff(staff_no, position, email, dob, phone, lecturer_id)
VALUES('SN002', 'Lecturer', 'charley@gmail.com', '12/07/1988', '076123222', 'LI003');

insert into staff(staff_no, position, email, dob, phone, lecturer_id)
VALUES('SN003', 'Lecturer', 'kargbo@gmail.com', '03/01/1978', '076123333', 'LI004');

insert into staff(staff_no, position, email, dob, phone, lecturer_id)
VALUES('SN004', 'Lecturer', 'nabie@gmail.com', '08/11/1998', '076123444', 'LI002');

insert into staff(staff_no, position, email, dob, phone, lecturer_id)
VALUES('SN005', 'Lecturer', 'agibu@gmail.com', '03/09/1990', '076123555', 'LI005');



/*Adding a column to each table*/
ALTER TABLE student
add Hobbie varchar(30);


ALTER TABLE parent
add nationality varchar(30);


ALTER TABLE module
add lecture_room varchar(30);


ALTER TABLE staff
add nationality varchar(30);


ALTER TABLE lecturer
add emp_type varchar(30);



/*UPDATING AN ATTRIBUTE IN EACH TABLE*/
EXEC sp_rename 'student.student_id', 'SID';

EXEC sp_rename 'parent.occupation', 'job_description';

EXEC sp_rename 'module.student_id', 'SID';

EXEC sp_rename 'staff.phone', 'contact';

EXEC sp_rename 'lecturer.lecturer_address', 'home_address';



/*Droping the Table created Earlier*/
ALTER TABLE student
drop column hobbie;

ALTER TABLE parent
drop column nationality;

ALTER TABLE module
drop column lecture_room;

ALTER TABLE staff
drop column nationality;

ALTER TABLE lecturer
drop column emp_type;

